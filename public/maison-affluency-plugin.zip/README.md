# Maison Affluency Trade Sync — Plugin Package

## Endpoints
- MCP (ChatGPT connector): https://dcrauiygaezoduwdjmsm.supabase.co/functions/v1/mcp-chatgpt
- Manifest: https://www.maisonaffluency.com/ai-plugin.json
- OpenAPI schema: https://www.maisonaffluency.com/.well-known/openapi.yaml
- OAuth consent: https://www.maisonaffluency.com/.lovable/oauth/consent

## Contents
- ai-plugin.json — plugin manifest (5 tools)
- openapi.yaml — OpenAPI schema for project sync + staging tools
- mcp-server/ — MCP server definition and tool sources (search_curator_picks, get_product, get_synced_projects, stage_product_to_project, calculate_trade_budget)
- edge-functions/ — backend functions: mcp-chatgpt (ChatGPT widget proxy), extension-sync-projects, extension-stage-product

Auth: OAuth 2.1 (authorization code + PKCE). Discovery: GET {endpoint} without a token returns 401 + WWW-Authenticate pointing at the resource metadata.
